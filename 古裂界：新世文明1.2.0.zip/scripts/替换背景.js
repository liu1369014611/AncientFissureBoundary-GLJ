//感谢神魂（来自年年有鱼）
importPackage(Packages.mindustry.graphics)

Events.on(EventType.ClientLoadEvent, () => {
const loadren = extend(MenuRenderer, {
    render(){
    Draw.color();
Draw.rect(Core.atlas.find("古裂界-a"), Core.graphics.getWidth() / 2, Core.graphics.getHeight() / 2, 2400, 1200);
    }
})

function Class(id) {
	return Seq([id]).get(0)
}

var fi = Class(MenuFragment).getDeclaredField("renderer");
fi.setAccessible(true);
fi.set(Vars.ui.menufrag, loadren);
})