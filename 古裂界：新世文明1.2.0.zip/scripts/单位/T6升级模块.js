const lib = require("base/coflib");
const mode = new UnitAssemblerModule("古裂界-T6升级模块");
mode.configurable = true;
mode.buildVisibility = BuildVisibility.sandboxOnly;
mode.buildType = prov(() => {
	let LV = 2;
	return extend(UnitAssemblerModule.UnitAssemblerModuleBuild, mode, {
		buildConfiguration(table) {
			table.button(Icon.refresh, Styles.cleari, run(() => {
				LV = 2;
				Vars.ui.showLabel(LV, 2, this.x, this.y);
			})).size(45);
			table.button(Icon.add, Styles.cleari, run(() => {
				if (LV < 3) {
					LV += 2;
					Vars.ui.showLabel(LV, 2, this.x, this.y);
				}
			})).size(45);
		},
		tier() {
			return LV;
		}
	})
})