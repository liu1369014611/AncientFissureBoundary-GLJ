const {UnitEngine} = UnitType;

const lib = require("蛇library");

const 蟒蛇end = lib.segment("蟒蛇-end", {
    hitSize: 13,
    flying: false,
}, {});

const 蟒蛇body = lib.segment("蟒蛇-body", {
    hitSize: 13,
    flying: false,
}, {});

const 蟒蛇 = lib.head("蟒蛇", {
    body: 蟒蛇body,
    end: 蟒蛇end,
    lengthSnake: 26,
    flying: false,
    hitSize: 25,
    speed: 1.5,
    health: 1000
}, {});