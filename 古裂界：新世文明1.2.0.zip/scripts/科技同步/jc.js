var laikeer = Vars.content.getByName(ContentType.planet, "古裂界-莱克尔");
if (laikeer == null) {
    print("欢迎来到莱克尔");
} else {
    laikeer.generator = new AsteroidGenerator();
    laikeer.meshLoader = prov(function() { return new HexMesh(laikeer, 6); });

    var cloudColor = Color.valueOf("BF021E");
    cloudColor.a = 0.4;
    laikeer.cloudMeshLoader = prov(function() {
        return new HexSkyMesh(laikeer, 7, 2, 0.2, 7, cloudColor, 3, 0.7, 1, 0.4);
    });

    laikeer.atmosphereColor = Color.valueOf("DD4B30");
    laikeer.atmosphereRadIn = 0;
    laikeer.atmosphereRadOut = 0.1;
    laikeer.lightColor = Color.valueOf("DD4B30");

    laikeer.visible = true;
    laikeer.bloom = true;
    laikeer.accessible = true;
    laikeer.alwaysUnlocked = false;
    // 莱克尔直接指向赛普罗科技树对象，实现解锁状态互通
    laikeer.techTree = Planets.serpulo.techTree;

    laikeer.ruleSetter = function(r) {
        r.waveTeam = Team.crux;
        r.placeRangeCheck = false;
        r.coreDestroyClear = true;
        r.env = Env.terrestrial;
    };
}

Events.on(ContentInitEvent, function() {
    var laikeer = Vars.content.getByName(ContentType.planet, "古裂界-莱克尔");
    if (laikeer == null) {
        print("欢迎来到莱克尔");
        return;
    }

    // ========== shownPlanets：原版 +【古裂界‑模组】全部加入莱克尔UI显示 ==========
    // 现在莱克尔科技面板同时看见原版科技 + 你的模组科技
    var allBlocks = Vars.content.getBy(ContentType.block);
    for (var i = 0; i < allBlocks.size; i++) {
        var block = allBlocks.get(i);
        var planets = block.shownPlanets;
        if (planets == null) planets = new Seq();
        if(!planets.contains(laikeer)){
            planets.add(laikeer);
        }
        block.shownPlanets = planets;
    }

    var allItems = Vars.content.getBy(ContentType.item);
    for (var i = 0; i < allItems.size; i++) {
        var item = allItems.get(i);
        var planets = item.shownPlanets;
        if (planets == null) planets = new Seq();
        if(!planets.contains(laikeer)){
            planets.add(laikeer);
        }
        item.shownPlanets = planets;
    }

    var allUnits = Vars.content.getBy(ContentType.unit);
    for (var i = 0; i < allUnits.size; i++) {
        var unit = allUnits.get(i);
        var planets = unit.shownPlanets;
        if (planets == null) planets = new Seq();
        if(!planets.contains(laikeer)){
            planets.add(laikeer);
        }
        unit.shownPlanets = planets;
    }

    var allLiquids = Vars.content.getBy(ContentType.liquid);
    for (var i = 0; i < allLiquids.size; i++) {
        var liquid = allLiquids.get(i);
        var planets = liquid.shownPlanets;
        if (planets == null) planets = new Seq();
        if(!planets.contains(laikeer)){
            planets.add(laikeer);
        }
        liquid.shownPlanets = planets;
    }

    var allStatus = Vars.content.getBy(ContentType.status);
    for (var i = 0; i < allStatus.size; i++) {
        var status = allStatus.get(i);
        var planets = status.shownPlanets;
        if (planets == null) planets = new Seq();
        if(!planets.contains(laikeer)){
            planets.add(laikeer);
        }
        status.shownPlanets = planets;
    }

    Log.info("莱克尔：与赛普罗共用同一科技树，原版+模组科技互通");
    exports.laikeer = laikeer;
});
