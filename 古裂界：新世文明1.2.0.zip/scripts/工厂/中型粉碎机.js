const library = require("base/library");
const myliquids = require("liquids");
const myitems = require("item");
const 中型粉碎机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "中型粉碎机", [
        {
            input: {
                items: ["copper/1,"]
                power: 1
            },
            output: {
                items: ["sand/1"]
            },
            craftTime: 15
        },
        {
            input: {
                items: ["lead/1,"]
                power: 1
            },
            output: {
                items: ["sand/1"]
            },
            craftTime: 15
        },
        {
            input: {
                items: ["coal/1,"]
                power: 1
            },
            output: {
                items: ["sand/1"]
            },
            craftTime: 15
        },
        {
            input: {
                items: ["titanium/1,"]
                power: 1
            },
            output: {
                items: ["sand/1"]
            },
            craftTime: 15
        },
        {
            input: {
                items: ["thorium/1,"]
                power: 1
            },
            output: {
                items: ["sand/1"]
            },
            craftTime: 15
        },
        {
            input: {
                items: ["metaglass/1,"]
                power: 1
            },
            output: {
                items: ["sand/2"]
            },
            craftTime: 15
        },
        {
            input: {
                items: ["sand/2,"]
                power: 1
            },
            output: {
                items: ["scrap/2"]
            },
            craftTime: 15
        },
]);
中型粉碎机.category = Category.crafting;
中型粉碎机.buildVisibility = BuildVisibility.shown;;
