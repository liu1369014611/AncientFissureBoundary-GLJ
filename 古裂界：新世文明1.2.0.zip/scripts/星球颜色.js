
const A = new Floor("A");
exports.A = A;
Object.assign(A, {
})

const B = new Floor("B");
exports.B = B;
Object.assign(B, {
})

const C = new Floor("C");
exports.C = C;
Object.assign(C, {
})