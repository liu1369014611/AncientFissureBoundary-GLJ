exports.modName = "古裂界";
exports.mod = Vars.mods.locateMod(exports.modName);

exports.maxDamage = Stat("maxDamage");
exports.regenAmount = Stat("regenAmount");
exports.damageReduction = Stat("damageReduction");

exports.addResearch = (content, research) => {
	if (!content) {
		throw new Error('content is null!');
	}
	if (!research.parent) {
		throw new Error('research.parent is empty!');
	}
	let researchName = research.parent;
	let customRequirements = research.requirements;
	let objectives = research.objectives;
	let lastNode = TechTree.all.find(boolf(t => t.content == content));
	if (lastNode != null) {
		lastNode.remove();
	}
	let node = new TechTree.TechNode(null, content, customRequirements !== undefined ? customRequirements : content.researchRequirements());
	if (objectives) {
		node.objectives.addAll(objectives);
	}
	if (node.parent != null) {
		node.parent.children.remove(node);
	}
	// find parent node.
	let parent = TechTree.all.find(boolf(t => t.content.name.equals(researchName) || t.content.name.equals(exports.modName + "-" + researchName)));
	if (parent == null) {
		throw new Error("Content '" + researchName + "' isn't in the tech tree, but '" + content.name + "' requires it to be researched.");
	}
	// add this node to the parent
	if (!parent.children.contains(node)) {
		parent.children.add(node);
	}
	// reparent the node
	node.parent = parent;
}

exports.newBlock = (name, con) => {
	const b = extend(Block, name, con || {});
	b.solid = b.update = b.hasItems = b.destructible = b.configurable = true
	b.envEnabled = Env.any;
	b.group = BlockGroup.none;
	b.priority = TargetPriority.base;
	b.category = Category.effect;
	b.buildVisibility = BuildVisibility.shown;
	return b
}

exports.setBuilding = (building, block, con) => {
	block.buildType = prov(() => {
		if (building == Building) {
			return extend(building, con);
		} else {
			return extend(building, block, con);
		}
	})
}

exports.region = (name) => {
	return Core.atlas.find(exports.modName + "-" + name);
}

exports.bundle = (text, num, num1) => {
	if (num1) {
		return Core.bundle.format(text, num, num1);
	} else if (num) {
		return Core.bundle.format(text, num);
	} else {
		return Core.bundle.get(text);
	}
}

exports.float = (speed, length) => {
	return Mathf.sin(Time.time * speed) * length;
}

function Colour(R, G, B, A) {
	if (G) {
		return new Color(R, G, B, A || 1);
	} else {
		return Color.valueOf(R);
	}
}
exports.Color = Colour;

exports.FF5845 = Colour("FF5845");
exports.FF6666 = Colour("FF6666");
exports.FF8663 = Colour("FF8663");

exports.AngleTrns = (ang, rad, rad2) => {
	if (rad2) {
		return {
			x: Angles.trnsx(ang, rad, rad2),
			y: Angles.trnsy(ang, rad, rad2)
		}
	} else {
		return {
			x: Angles.trnsx(ang, rad),
			y: Angles.trnsy(ang, rad)
		}
	}
}

exports.DoubleTri = (x, y, width, length, angle, len) => {
	Draw.z(Layer.effect);
	Drawf.tri(x, y, width, length, angle + 180);
	Drawf.tri(x, y, width, length / (len || 4), angle);
}

function Halo(obj) {
	let def = {
		progress: DrawPart.PartProgress.warmup,
		mirror: true,
		x: 0,
		y: 0,
		moveX: 0,
		moveY: 0,
		shapeMR: 0,
		shapeR: 0,
		shapes: 2,
		radius: 4,
		radiusTo: -1,
		triL: 1,
		triLT: -1,
		haloRad: 0,
		haloRot: 0,
		haloRS: 0,
		color: exports.FF5845,
		colorTo: exports.FF6666
	}
	for (let k in def) {
		if (obj[k] == undefined) continue
		def[k] = obj[k]
	}
	return Object.assign(new HaloPart, {
		progress: def.progress,
		mirror: def.mirror,
		tri: true,
		x: def.x,
		y: def.y,
		moveX: def.moveX,
		moveY: def.moveY,
		shapeMoveRot: def.shapeMR,
		shapeRotation: def.shapeR,
		shapes: def.shapes,
		radius: def.radius,
		radiusTo: def.radiusTo,
		triLength: def.triL,
		triLengthTo: def.triLT,
		haloRadius: def.haloRad,
		haloRotation: def.haloRot,
		haloRotateSpeed: def.haloRS,
		color: def.color,
		colorTo: def.colorTo,
		layer: 110
	})
}
exports.Halo = Halo;

exports.DoubleHalo = (e, obj) => {
	e.parts.add(
		Halo({
			progress: obj.progress,
			mirror: obj.mirror,
			x: obj.x,
			y: obj.y,
			moveX: obj.moveX,
			moveY: obj.moveY,
			shapeMR: obj.shapeMR,
			shapes: obj.shapes,
			radius: obj.radius,
			radiusTo: obj.radiusTo,
			triL: obj.triL,
			triLT: obj.triLT,
			haloRad: obj.haloRad,
			haloRot: obj.haloRot,
			haloRS: obj.haloRS,
			color: obj.color,
			colorTo: obj.colorTo
		}),
		Halo({
			progress: obj.progress,
			mirror: obj.mirror,
			x: obj.x,
			y: obj.y,
			moveX: obj.moveX,
			moveY: obj.moveY,
			shapeMR: obj.shapeMR,
			shapeR: 180,
			shapes: obj.shapes,
			radius: obj.radius,
			radiusTo: obj.radiusTo,
			triL: obj.triL / 4 || 1,
			triLT: obj.triLT / 4 || -1,
			haloRad: obj.haloRad,
			haloRot: obj.haloRot,
			haloRS: obj.haloRS,
			color: obj.color,
			colorTo: obj.colorTo
		})
	)
}