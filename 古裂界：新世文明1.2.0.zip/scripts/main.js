MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("辅助/缩放");
require("单位/copters");
require("蛇");
require("单位/甲虫转换模块");
require("替换背景");
require("蛇library");
require("科技同步/jc");
//#########################################//娱乐
require("娱乐/破墙仪");
require("娱乐/反引力");
require("娱乐/正引力");

















//注我拿的是蔚蓝行星的
//以下注释为VSHES荔枝独立完成为了让其他蔚蓝开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
       var dialogo = new BaseDialog("[green]古裂界\nGIJ");//新建一个显示窗口
	dialogo.buttons.button("@close", run(() => {
		dialogo.hide()//退出此界面
	})).size(210, 64);//按钮用原版@close贴图

    dialogo.cont.pane(table => {//滑动显示
        
		table.image(Core.atlas.find("logo")).left().size(600, 100).pad(3).row();//显示logo图片

		table.add("[#8800CCFF]欢迎游玩古裂界模组！\n[white]本模组添加了一个新的行星<莱克尔><普瑞克斯>").left().growX().wrap().pad(4).labelAlign(Align.left).row();
		 let label = new FLabel("[white]模组QQ群: {rainbow}292950475");
		 table.add(label).left().row();
		 table.add("[green]v0.0.8更新内容:[white]\n更新了一些单位\n增加了几个炮台\n修改了一些贴图\n修改了虫族属性\n增加了一个大型单位\n修改了一些单位的贴图\n[green]0.2.5更新内容:[white]\n新增几种炮塔\n新增几个工厂\n新增几个物品\n修改了其他小部分一点属性\n[green]0.4.8更新内容:[white]\n修改了大部分炮台的属性\n补齐了船支t1~t6\n删除一个炮台<创始>\n新增了4个虫族\n新增了几个物品\n新增了几个工厂\n新增1个炮台<凤台>\n新增一个单位工厂\n新增巨型墙壁\n[green]0.4.9更新内容:[white]\n增加了一个T7\n修改了很多单位属性\n修改了运输点，运输慢的问题\n[green]1.0.0更新内容:[white]\n新增全部T7\n新增炮台\n新增星球\n修改了部分贴图\n炮台的数值重新调整达到平衡\n新增的几个炮台\n虫族更新完毕\n新增了几个音效\n增加了几个特殊单位\n删除一个单位<曙光>\n新增多种地块<仅在编辑器可见>\n虫族的地图一共13张\n增加了一些物品\n修改了一下天气系统的图片\n新增一个装饰<肿瘤晶体树>\n删除了虫族科技树\n修改了工厂的电力和物品消耗\n[green]v1.0.5更新内容:\n[white]减少<T7,6,5直升机>的导弹数量,增强机枪伤害,以及增强<导弹>的伤害\n全部<T7><T6>生命加高和小幅度提升防御\n<功能重建厂>将可制作实验单位<烛龙>和<狂热>\n一些<物品>的重绘\nT7<海豹>的主炮提升发射数量\n全部<墙>的生命提高\n<白灵>，<飞削>，<回旋>，狂妄，<吸力>，<打击>，都伤害增加\n<预厄>的宏电合金伤害下降\n<主义>极硬晶体弹药伤害提升\n<临界液体厂>制作临界液材料提升\n<宏电合金厂>增加相织布制作材料\n调整<古能源厂>材料\n<青龙>一些炮台小幅度伤害降低\n大部分音效变成以前音效，\n[green]v1.1.0\n[red]加新boss古戈\n新加新科技新星球,在新星球挖的资源不可研究科技，只能在赛普罗研究。\n[green]v1.1.3\n[white]添加新的boss夜曲\n更改一些科技路线\n某些炮台图片增加细节\n调整一些炮台的数值平衡\n两个星球将无法再降落\n新增炮台<铜管><净静>\n修复了一些不在科技上的炮台和工厂\n一台超大型发电机的图片增加细节。\n[green]1.1.5\n[red]完成了科技互通与修复\n[white]修改了一些t6t7的图片与单位炮塔图片\n对<叕管><铜管>进行了削弱\n重新开起莱克尔星球战役\n[green]v1.2.0\n[white]加强了<焰心><雹灾><浪水><瑟缩><孤独><犹恕><狂蜂><齐聚><涡流><雷明><冰涌><汽旋><灾灵>\n削弱了<净静>\n对地图支线修改，地图重叠的修复和地图问题的修复\n狂热的制作材料提升，<功能重建厂>将可制作实验单位<吞灭>和<燃眉>\n虫族boss的图片缩小，和增加细节\n赛普罗的第2科技线推出，将可研究实验型单位以及炮台\n单位<夜曲>的机炮进行削弱\n新增单位<冲锋>\n更新关于埃里克尔的新炮台与新的T6单位，他们都在研究科技树上，可以直接研究\n修改了夜曲的图片，使其更美观\n修复了一些代码问题。"
).left().growX().wrap().width(580).maxWidth(580).pad(4).labelAlign(Align.left).row();

	}).grow().center().maxWidth(600)
             dialogo.show();
}))